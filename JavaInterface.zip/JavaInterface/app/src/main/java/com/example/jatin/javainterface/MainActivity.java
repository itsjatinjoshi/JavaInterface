package com.example.jatin.javainterface;

import android.annotation.SuppressLint;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.RelativeLayout;
import android.widget.Button;
import android.graphics.Color;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    @SuppressLint("ResourceType")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        RelativeLayout JatinLayout= new RelativeLayout(this);
        JatinLayout.setBackgroundColor(Color.BLUE);

        Button redBtton= new Button(this);
        redBtton.setText("Click Here");
        redBtton.setBackgroundColor(Color.GRAY);

        EditText userName = new EditText(this);
        redBtton.setId(01);
        userName.setId(02);

        RelativeLayout.LayoutParams buttonDetails = new RelativeLayout.LayoutParams(
        RelativeLayout.LayoutParams.WRAP_CONTENT,
        RelativeLayout.LayoutParams.WRAP_CONTENT
         );

        RelativeLayout.LayoutParams userNameDetail = new RelativeLayout.LayoutParams(
        RelativeLayout.LayoutParams.WRAP_CONTENT,
        RelativeLayout.LayoutParams.WRAP_CONTENT
        );

        userNameDetail.addRule(RelativeLayout.ABOVE,redBtton.getId());
        userNameDetail.addRule(RelativeLayout.CENTER_HORIZONTAL);
        userNameDetail.setMargins(0,0,0,50);

        buttonDetails.addRule(RelativeLayout.CENTER_HORIZONTAL);
        buttonDetails.addRule(RelativeLayout.CENTER_VERTICAL);

        JatinLayout.addView(redBtton, buttonDetails);
        JatinLayout.addView(userName, userNameDetail);

        JatinLayout.addView(redBtton, buttonDetails);
        setContentView(JatinLayout);

    }
}
